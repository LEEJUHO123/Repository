package co.edu;

public class HelloWorld { // 클래스
	
	public static void main(String[] args) { // 메소드
		System.out.println("Hello, World!!");
		System.out.println("안녕하세요, 저는.");
		System.out.println("안녕히가세요.");
	}
}