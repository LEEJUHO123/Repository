package co.edu.variable;

import java.util.Scanner;

public class Orange2 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		
		System.out.println();
		int orange, ten, five;
		
		orange = 127;
		ten = 10;
		five = 5;
		
		int a = orange / ten;   //10개씩 12상자
		int b = orange % ten;   // 남은 7개
		int c = b / five;    // 5개씩 1상자
		int d = c % five;   // 남은 2개 
		
		System.out.printf("오렌지 %d개, 10개씩 담을 수 있는 상자는 %d, 5개씩 담을 수 있는 상자는 %d", orange, a, (c+d));
	}
}
