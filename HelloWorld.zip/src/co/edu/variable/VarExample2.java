package co.edu.variable;

public class VarExample2 {
	public static void main(String[] args) {
		// 국어 80, 영어 70, 수학 63
		// 평균 변수 선언. (+ + +) /
 		
		System.out.println("80점, 70점, 63점이 평균: 71점 입니다" );
		
		// 국어 85, 영어 75, 수학 60  200/3 = 73.3333
		
		double avg = (85 + 75 + 60) / 3.0;
		
		
		
		System.out.println("80점, 70점, 63점이 평균 71점 입니다" + avg);
		
		}
}
