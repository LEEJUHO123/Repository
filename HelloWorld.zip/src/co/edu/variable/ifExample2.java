package co.edu.variable;

public class ifExample2 {
	public static void main(String[] args) {
		int num1, num2;
		
		num1 = 123;
		num2 = 234;
		
		if(num1 > num2) {
			System.out.println("큰 수는 : " + num1);
		} else {
			System.out.println("큰 수는 : " + num2);
		}
	}
}
