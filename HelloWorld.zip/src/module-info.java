module HelloWorld {
	requires java.se;
}