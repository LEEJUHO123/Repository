package Mystudy;

public class Study {

}
