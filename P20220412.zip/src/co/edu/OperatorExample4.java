package co.edu;

public class OperatorExample4 {
	public static void main(String[] args) {
		// 삼항 연산자.
		int num = 10;
		String msg = "";
		if(num % 2 == 0) {
			msg = "짝수입니다.";
		}else {	
			msg = " 홀술입니다.";
		}
		
		msg = (num % 2 == 0) ? "짝수입니다." : "홀수입니다.";   //if 구문 간단하게 사용!!!
		
		System.out.println(num + "은" + msg);
	}
}