module P20220412 {
	requires java.se;
}