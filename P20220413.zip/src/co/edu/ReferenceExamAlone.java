package co.edu;

public class ReferenceExamAlone {
	public static void main(String[] args) {
		
		int num1 = 100;
		int num2 = 100;
		
		if(num1 == num2) {
			System.out.println("같은값.");
		}else {
			System.out.println("다른 값");
			
		}
		
		String str1 = new String("홍길동");
		
		
		
		
		
	}
}
