package co.edu.dimension;

public class AloneArray {
	public static void main(String[] args) {
		
	
		
		
		
	}
}
