package co.edu.dimension;

public class Student {
	//학생이름, 점수
	String studName;
	int score;
	int age;
}
